

<?php $__env->startSection('title'); ?>
  Event View
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
   
<center><div class="container mt-5">
       
       <div class="card bg-secondary " style="border: solid black 5px; width: 40rem; height: 35rem ">
           <div class=" md-3 pt-4">

                 <h3 class="text-dark">EVENT DETAILS</h3><br><br>

                        <h5> <b class="text-dark;" >Event Name:  </b> <?php echo e($event->event_column); ?></h5><br><br>

                        <h5> <b class="text-dark" >Event Date:  </b> <?php echo e($event->date); ?></h5><br><br>

                        <h5> <b class="text-dark" >Event Venue: </b> <?php echo e($event->venue); ?></h5><br><br>

                        <h5> <b class="text-dark" >Event In Charge: </b> <?php echo e($event->in_charge); ?></h5><br><br>

                        <a href="<?php echo e(route('front-page')); ?>" class="mt-4 btn btn-warning">Back</a>


    
             </div>
      
       </div>
   </div>     

    

            
            
   
       
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laravel app\final_project\resources\views/pages/view.blade.php ENDPATH**/ ?>