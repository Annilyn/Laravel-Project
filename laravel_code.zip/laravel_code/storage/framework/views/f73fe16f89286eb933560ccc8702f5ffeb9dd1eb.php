
<?php $__env->startSection('title'); ?>
  HOME
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
   <div class="container mt-4">
       <?php if($message = Session::get('success')): ?>
            <div class="alert alert-danger">
              <p><?php echo e($message); ?></p>
            </div>
        <?php endif; ?>

      <h2> ACD Events Management System</h2>

      <br><div class="mt-2 col-mid-5 offest-md-2">
        <a href="<?php echo e(route('front-page')); ?>" class="btn btn-info text-back fw-bold ">Home</a>
        <a href="<?php echo e(route('add')); ?>" class="btn btn-info text-back fw-bold ">Create Event</a>
      </div><br>
      

         
         <div class="row">
            <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
           
               
  <div class="col-sm-4 mt-5">
    <div class="card">
      <div class="card-body bg-info" style="border: solid gray 2px;">
              

                        <div class="del "style="text-align: right;">
                           <a href="<?php echo e(route('delete', $event->id)); ?>" class="btn btn-danger" onclick="return confirm('Are you sure you want to delete it?');">Delete</a>
                        </div>

                       <center><br><h5 class="card-title text-back fw-bold fs-1 pt-1"><?php echo e($event->event_column); ?></h5><br>
        
                         <a href="<?php echo e(route('show', $event->id)); ?>" class="btn btn-primary">View</a>
                         <a href="<?php echo e(route('edit', $event->id)); ?>" class="btn btn-secondary">Edit</a>

                      </center>

      </div>
    </div>
  </div>
            
             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  
         
</div>      
       
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laravel app\final_project\resources\views/pages/home.blade.php ENDPATH**/ ?>