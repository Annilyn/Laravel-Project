<!DOCTYPE html>
<html>
<head>

	<title><?php echo $__env->yieldContent('title'); ?></title>
	<link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.min.css')); ?>">
	
</head>
<body>

<?php echo $__env->yieldContent('content'); ?>
    <script src="<?php echo e(asset('js/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/bootstrap.bundle.min.js')); ?>"></script> 
    <script type="text/javascript"></script>
</body>
</html><?php /**PATH C:\laravel app\final-ROMA\final_Code\resources\views/layout/master.blade.php ENDPATH**/ ?>