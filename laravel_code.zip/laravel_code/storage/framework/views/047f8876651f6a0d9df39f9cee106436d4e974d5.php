

<?php $__env->startSection('title'); ?>
  Add Events
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
   <div class="container mt-5">
       <center>
          <div class="card bg-secondary" style="border: solid black 5px; width: 50rem; height: 40rem ">
            <div class="col-md-4 offset-md-4 pt-5">



               <form action="<?php echo e(route('insert')); ?>" method="post">
                         <?php echo csrf_field(); ?>
                         <?php echo method_field('post'); ?>

                  <div class="form-group mb-5"><h1>ADD EVENT</h1><br>
                        <div class="mb-4">
                           <label><h4>Event Name</h4></label>
                           <input type="text" class="form-control" name="event_input" required="" placeholder="Event Name">
                        </div>

                        <div class="mb-4">
                           <label for="date"><h4>Event Date</h4></label><br>
                           <input type="date" class="form-control" id="date" name="date" required="">
                        </div> 

                        <div class="mb-4">
                           <label class="form-label"><h4>Event Venue</h4></label>
                           <input type="text" class="form-control" name="event_venue" required="" placeholder="Event Venue">
                        </div>

                        <div class="mb-4">
                          <label class="form-label"><h4>Event In Charge</h4></label>
                          <input type="text" class="form-control" name="event_incharge" required="" placeholder="Event In Charge">
                        </div>




                    <label>  <a href="<?php echo e(route('front-page')); ?>" class="mt-2 btn btn-warning">Cancel</a>
                           <input type="submit" value="Create" class="mt-2 btn btn-info">
                   </label>

                </div>

              </form>
        
   
         </div>
      </div>
   </cender>
</div>      
       
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laravel app\final-project\final_Code\resources\views/pages/add.blade.php ENDPATH**/ ?>