


<?php $__env->startSection('title'); ?>
  Edit Event
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="container  mt-5">
       
  <center>
    <div class="card bg-secondary" style="border: solid black 5px; width: 50rem; height: 40rem ">
      <div class="col-md-4 offset-md-4 pt-5">

         
              <h1>EDIT EVENT</h1><br>



                  <form action="<?php echo e(route('update',$event->id)); ?>" method="post">
                       <?php echo csrf_field(); ?>
                       <?php echo method_field('post'); ?>



                        <div class="form-group">
                                    <div class="mb-4">
                                        <label class="form-label"><h4>Event Name</h4></label>
                                        <input type="text" value="<?php echo e($event->event_column); ?>" class="form-control" name="event_input" required="" placeholder="">
                                    </div>

                                    <div class="mb-4">
                                         <label class="form-label"><h4>Event Date</h4></label><br>
                                         <input type="date" value="<?php echo e($event->date); ?>" class="form-control" name="date" required="" placeholder="">
                                    </div>
              
                                    <div class="mb-4">
                                        <label class="form-label"><h4>Event Venue</h4></label><br>
                                        <input type="text" value="<?php echo e($event->venue); ?>" class="form-control" name="event_venue" required="" placeholder="">
                                    </div>
              
                                    <div class="mb-4">
                                        <label class="form-label"><h4>Event In Charge</h4></label><br>
                                        <input type="text" value="<?php echo e($event->in_charge); ?>" class="form-control" name="event_incharge" required="" placeholder="">
                                    </div>

                                          <label><a href="<?php echo e(route('front-page')); ?>" class="mt-2 btn btn-warning">Cancel</a>
                                          <input type="submit" value="Update" class="mt-2 btn btn-primary"></label>

                         </div>
                  </form>
      </div>

    </div>

  </center>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laravel app\final-project\final_Code\resources\views/pages/edit.blade.php ENDPATH**/ ?>