
@extends('layout.master')
@section('title')
  HOME
@endsection
@section('content')
   <div class="container mt-4">
       @if($message = Session::get('success'))
            <div class="alert alert-danger">
              <p>{{$message}}</p>
            </div>
        @endif

      <h2> ACD Events Management System</h2>

      <br><div class="mt-2 col-mid-5 offest-md-2">
        <a href="{{route('front-page')}}" class="btn btn-info text-back fw-bold ">Home</a>
        <a href="{{route('add')}}" class="btn btn-info text-back fw-bold ">Create Event</a>
      </div><br>
      

         
         <div class="row">
            @foreach ($events as $event)
           
               
  <div class="col-sm-4 mt-5">
    <div class="card">
      <div class="card-body bg-info" style="border: solid gray 2px;">
              

                        <div class="del "style="text-align: right;">
                           <a href="{{route('delete', $event->id)}}" class="btn btn-danger" onclick="return confirm('Are you sure you want to delete it?');">Delete</a>
                        </div>

                       <center><br><h5 class="card-title text-back fw-bold fs-1 pt-1">{{$event->event_column}}</h5><br>
        
                         <a href="{{route('show', $event->id)}}" class="btn btn-primary">View</a>
                         <a href="{{route('edit', $event->id)}}" class="btn btn-secondary">Edit</a>

                      </center>

      </div>
    </div>
  </div>
            
             @endforeach  
         
</div>      
       
@endsection