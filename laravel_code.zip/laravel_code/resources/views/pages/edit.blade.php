

@extends('layout.master')
@section('title')
  Edit Event
@endsection
@section('content')
<div class="container  mt-5">
       
  <center>
    <div class="card bg-secondary" style="border: solid black 5px; width: 50rem; height: 40rem ">
      <div class="col-md-4 offset-md-4 pt-5">

         
              <h1>EDIT EVENT</h1><br>



                  <form action="{{route('update',$event->id)}}" method="post">
                       @csrf
                       @method('post')



                        <div class="form-group">
                                    <div class="mb-4">
                                        <label class="form-label"><h4>Event Name</h4></label>
                                        <input type="text" value="{{$event->event_column}}" class="form-control" name="event_input" required="" placeholder="">
                                    </div>

                                    <div class="mb-4">
                                         <label class="form-label"><h4>Event Date</h4></label><br>
                                         <input type="date" value="{{$event->date}}" class="form-control" name="date" required="" placeholder="">
                                    </div>
              
                                    <div class="mb-4">
                                        <label class="form-label"><h4>Event Venue</h4></label><br>
                                        <input type="text" value="{{$event->venue}}" class="form-control" name="event_venue" required="" placeholder="">
                                    </div>
              
                                    <div class="mb-4">
                                        <label class="form-label"><h4>Event In Charge</h4></label><br>
                                        <input type="text" value="{{$event->in_charge}}" class="form-control" name="event_incharge" required="" placeholder="">
                                    </div>

                                          <label><a href="{{route('front-page')}}" class="mt-2 btn btn-warning">Cancel</a>
                                          <input type="submit" value="Update" class="mt-2 btn btn-primary"></label>

                         </div>
                  </form>
      </div>

    </div>

  </center>

</div>
@endsection