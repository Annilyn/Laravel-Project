
@extends('layout.master')
@section('title')
  Event View
@endsection
@section('content')
   
<center><div class="container mt-5">
       
       <div class="card bg-secondary " style="border: solid black 5px; width: 40rem; height: 35rem ">
           <div class=" md-3 pt-4">

                 <h3 class="text-dark">EVENT DETAILS</h3><br><br>

                        <h5> <b class="text-dark;" >Event Name:  </b> {{$event->event_column}}</h5><br><br>

                        <h5> <b class="text-dark" >Event Date:  </b> {{$event->date}}</h5><br><br>

                        <h5> <b class="text-dark" >Event Venue: </b> {{$event->venue}}</h5><br><br>

                        <h5> <b class="text-dark" >Event In Charge: </b> {{$event->in_charge}}</h5><br><br>

                        <a href="{{route('front-page')}}" class="mt-4 btn btn-warning">Back</a>


    
             </div>
      
       </div>
   </div>     

    

            
            
   
       
@endsection