<!DOCTYPE html>
<html>
<head>

	<title>@yield('title')</title>
	<link rel="stylesheet" href="{{asset('css/bootstrap.min.css')}}">
	
</head>
<body>

@yield('content')
    <script src="{{asset('js/jquery.min.js')}}"></script>
    <script src="{{asset('js/bootstrap.bundle.min.js')}}"></script> 
    <script type="text/javascript"></script>
</body>
</html>