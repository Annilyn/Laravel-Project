<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Event;
class EventController extends Controller
{
    public function index(){
    	$events = Event::all();
    	

    	return view("pages.home")->with("events", $events);
    }

     public function insert(Request $request){
        $event = new Event();

         // call the name of culonm table
    	$event->event_column = $request->event_input;
    	$event->date = $request->date;
    	$event->venue = $request->event_venue;
    	$event->in_charge = $request->event_incharge;


    	$event->save();
    	return redirect()->route('front-page')->with('success', 'Add Event Successfully.!!');
    }

    public function show($id){

 	      $event = Event::find($id);
    	

    	return view("pages.view")->with("event", $event);
    }

    public function edit($id){
    	// return $id;
    	$event = Event::find($id);
    	return view("pages.edit")->with("event", $event);
    }

    public function update(Request $request, $id){
    	$event = Event::find($id);
    	$event->event_column = $request->event_input;
    	$event->date = $request->date;
    	$event->venue = $request->event_venue;
    	$event->in_charge = $request->event_incharge;


    	$event->save();
    	return redirect()->route('front-page')->with('success', 'Event Updated Successfully.!!');
    }


    public function delete($id){
    	$Event = Event::find($id);
        event::destroy($id);
        return redirect()->route('front-page')->with('success', 'Event Deleted Successfully.!!');

     }
}